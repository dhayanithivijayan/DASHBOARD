/*setting add url button and input*/
const addUrlButton=document.getElementById('addurlbtn')
addUrlButton.style.opacity=0.3
addUrlButton.addEventListener('click',addUrl)

const urlInput=document.getElementById('urlinput')
urlInput.addEventListener('input',verifyUrlInput)


function addUrl(e){
    /*verify input*/
    const inputUrlvalue=urlInput.value;
    if(inputUrlvalue.length>3){
        const addUrlDiv=document.querySelector('.addurls')
        const newUrldiv=document.createElement('div')
        const newSpan=document.createElement('span')
        const newButton=Button=document.createElement('button')
        
        newSpan.innerText=inputUrlvalue
        newButton.innerText='delete'
        
        newUrldiv.classList.add('newurl')
        newButton.classList.add('deleteurlbtn')
        
        newUrldiv.appendChild(newSpan)
        newUrldiv.appendChild(newButton)
        addUrlDiv.appendChild(newUrldiv)
        
        updateCount()
        
        
        addUrlButton.disabled=true;
        addUrlButton.style.opacity=0.3
        urlInput.value=''
        addEventToDeleteButton(newButton,newUrldiv)
    }
}

function updateCount(){
    let urls=document.querySelectorAll('.newurl')
    let noOfUrl=urls.length;
    document.querySelector('#urlcountvalue').innerText=noOfUrl
    
}


function verifyUrlInput(e){
    if(e.target.value.length>3){
        addUrlButton.disabled=false;
        addUrlButton.style.opacity=1
    }
}

function addEventToDeleteButton(button,parentDiv){
 
   button.addEventListener('click',()=>{
       deleteUrl(parentDiv)
   })
   
}

function deleteUrl(parentDiv){
    document.querySelector('.addurls').removeChild(parentDiv)
    updateCount()
}




